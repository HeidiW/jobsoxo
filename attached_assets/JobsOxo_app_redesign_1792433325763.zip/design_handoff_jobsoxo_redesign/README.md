# Handoff: JobsOxo redesign (direction 1a "Bold")

## Overview
Visual redesign of the JobsOxo web app (invoicing, payroll and job management for small construction businesses). It covers every page in the main menu: Dashboard, Clients, Jobs, Job detail, Materials, Invoices, New invoice, Change Orders, Scheduling, Payroll (with Gusto worksheet), Inbox, and Settings. The primary user is a non-technical tradesperson, so the design uses big type, bordered button-style navigation, large tap targets, and plain-language copy.

## About the design files
`prototype/JobsOxo App.dc.html` is a **design reference built in HTML**. It is a clickable prototype that shows the intended look and behavior, not production code. Recreate it inside the existing JobsOxo codebase (React + Vite + Tailwind + shadcn/ui, wouter routing, TanStack Query, Drizzle schema in `shared/schema.ts`), using its existing components, routes and data hooks. Do **not** copy the HTML, the inline styles, or the sample data. Real data comes from the existing API.

To view the prototype, open the `prototype/` folder with any static server (for example `npx serve prototype`) and load `JobsOxo App.dc.html`. Keep the three files in that folder together.

## Fidelity
**High fidelity.** Colors, type, radii, spacing and copy are final. Match them using the Tailwind tokens in `theme.css` and `tailwind.config.additions.ts`.

## Step 1: tokens (do this first)
1. In `client/src/index.css`, replace the `:root { … }` and `.dark { … }` variable blocks with the ones in `theme.css`, and add its `@import` for the fonts at the top.
2. Merge `tailwind.config.additions.ts` into `theme.extend` in `tailwind.config.ts`. This adds the `jx-*` colors, `font-display` and `font-mono`, and the larger radii.
3. Because `--primary` is now green, every existing `bg-primary` button turns green automatically. Check nothing still uses the old oxblood red.

## Global layout
- **App shell:** a flex row. The sidebar is `w-[248px] shrink-0 sticky top-0 h-screen border-r border-jx-line px-4 py-6 flex flex-col gap-6`. Main is `flex-1 min-w-0`.
- **Top bar:** `h-[60px] sticky top-0 bg-background border-b border-jx-line px-8 flex items-center gap-3.5`.
  - Breadcrumb: `JobsOxo / Section / Item`, 13px, ink-3, with the current item in ink at weight 600.
  - Right side: a search pill (`w-[260px] rounded-full bg-jx-surface px-3.5 py-2.5 text-[13px] text-jx-ink-3`) and a 38px round theme toggle (moon/sun icon).
- **Page padding:** `px-10 pt-10 pb-14 flex flex-col gap-5` (detail pages use `pt-8`).
- **Page header:** title on the left, primary action on the right, `flex items-end justify-between flex-wrap gap-6`.
  - Title: `font-display font-bold text-[64px] leading-[.95] tracking-display`. The Dashboard greeting is 72px, and "Good morning," is in `text-jx-green`.
  - Subtitle: `text-[17px] text-jx-ink-2`, 12px below the title.

### Sidebar navigation (user-research requirement)
- Every item is a **bordered button**: `flex items-center gap-3 px-4 py-3 rounded-full border-2 border-jx-ink-3 bg-card text-[15px] font-semibold text-jx-ink hover:border-jx-green`. Items sit 8px apart (`gap-2`).
- **Active item:** `bg-jx-green border-jx-green text-white`.
- **Icons:** lucide-react at 17px.
- **Items:** Dashboard (LayoutDashboard), Clients (Users), Jobs (Briefcase), Materials (Package), Invoices (FileText), Change Orders (TriangleAlert), Scheduling (Calendar), Payroll (DollarSign), Inbox (Inbox). Settings sits on its own under a "System" label.
- **Consolidation:** Gusto Worksheet is now a tab inside Payroll. Inbox Tasks and Gmail Todos are merged into one Inbox page.
- **Count badge:** Inbox and Change Orders show a count at the right end of the button (`rounded-full px-2 py-0.5 text-xs font-semibold bg-jx-orange-tint text-jx-orange-ink`; on the active item, `bg-white/20 text-white`).
- **Section labels** ("Main menu", "System"): 12px, weight 500, ink-3.
- **Logo:** a 36px green rounded-[10px] square with a PaintBucket icon, then "JOBSOXO" (Inter Tight 800, 17px, tracking -0.03em) and "Invoicing" (Inter Tight 400, 14px, ink-2).
- **Footer:** user card, `mt-auto rounded-[14px] bg-jx-surface p-3` with a gold-tint avatar.

## Visual language
- **Big cards:** `rounded-3xl p-7` filled with a **tint** (`bg-jx-green-tint`, `bg-jx-blue-tint`, `bg-jx-orange-tint`, `bg-jx-gold-tint`, `bg-jx-surface`). No borders and no shadows.
- **Hero / solid card:** one per page at most. `bg-jx-green text-white rounded-3xl p-8`. Stat tiles inside it use `bg-white/12 rounded-2xl px-[18px] py-4`. Its buttons are a white-filled pill with green-ink text, and an outline pill with `border-white/60`.
- **Tables:** a container `bg-jx-surface rounded-3xl p-3 flex flex-col gap-2 overflow-x-auto`, with a header row `px-[18px] text-xs font-semibold uppercase tracking-[.06em] text-jx-ink-3`.
  - Each row is a white card: `bg-card rounded-2xl px-[18px] py-4 border-2 border-transparent hover:border-jx-green`.
  - Give the header and row grids `min-w-[1000px]` so narrow screens scroll sideways instead of overlapping.
- **Buttons:**
  - Primary: `rounded-full bg-jx-green hover:bg-jx-green-hover text-white px-[22px] py-3 text-sm font-semibold tracking-[.02em]`. The label is UPPERCASE ("NEW INVOICE").
  - Secondary: `rounded-full border-[1.5px] border-jx-ink px-[22px] py-3 text-sm font-semibold`.
- **Filter pills:** the same shape as the nav buttons (`border-2 border-jx-ink-3 rounded-full px-[18px] py-2.5`), with a mono count. The active pill is filled green.
- **Status chips:** `rounded-full px-[11px] py-[5px] text-xs font-semibold` on the matching tint and ink.
- **Money:** always `font-mono` (IBM Plex Mono), weight 500. Hero figures 76px, stat cards 34–38px, table amounts 15–16px, right-aligned.
- **Form fields:** `rounded-[14px] border-2 border-jx-ink-3 px-4 py-3.5 text-[15px] font-medium`. Labels are 13px semibold, 6px above the field.

### What the accent colors mean (use sparingly)
| Meaning | Color |
|---|---|
| Brand, primary actions, In progress, Paid, Approved | green |
| Quoted, Sent, Invoiced, Materials module | blue |
| Overdue, Needs attention, Declined, Change Orders module | orange |
| Scheduled, Partly paid, Awaiting client, Payroll module | gold |
| Draft, Completed | neutral (surface + ink-2) |

The four jobs also keep a consistent color across the dashboard week strip and Scheduling bars.

## Screens
Field names refer to `shared/schema.ts`.

### Dashboard (`/`)
1. **Header.** Greeting plus today's date. Actions: "New job" (secondary) and "NEW INVOICE" (primary).
2. **Row 1** (`grid auto-fit minmax(440px,1fr) gap-5`):
   - **This week on site** (`bg-jx-surface`): a 5-column Mon–Fri strip. Each day is a white `rounded-[14px]` column (min-height 200px) holding job chips in the job's tint ("Gramercy · Crew of 4"). Clicking a chip opens the job. "Scheduling →" link.
   - **Needs attention** (`bg-jx-orange-tint`, title in orange-ink): up to 3 white row cards, each showing client, project · invoice number (mono), a status line colored by urgency, the amount, and a "Remind" outline pill. After sending, the pill becomes a green "Sent ✓".
3. **Row 2:**
   - **Green hero card:** "Total outstanding" (76px mono), "across N open invoices · N clients", 3 stat tiles (Overdue, Due soon, Draft), and two buttons, "Send reminders" and "View invoices".
   - **Site photo card:** `min-h-[340px] rounded-3xl`, with a floating white card "ON SITE TODAY · job · client · crew · % complete" that links to the job.
4. **Row 3:** three tinted stat cards, each with a 36px icon and a 38px mono figure: Collected this month (blue), Active jobs (green), Unscheduled (gold).

### Clients
A card grid (`auto-fill minmax(340px,1fr)`), each card on its own tint. Each card shows:
- an initials tile, the name (Inter Tight 700, 21px) and the general contractor line (`generalContractorName`);
- contact, phone and address rows, each with an icon;
- a white inner box with "Open balance" and "Jobs";
- two buttons: "View jobs" and "New invoice".

### Jobs
Status filter pills (All, Quoted, Scheduled, In progress, Completed) above the table. Table columns are:
- a 64×48 thumbnail;
- Job (title + client · neighborhood);
- Dates;
- Status chip;
- Estimate (`estimatedTotal`, mono, right-aligned);
- Progress (an 8px bar in green plus a %).

Clicking a row opens Job detail.

### Job detail (`/jobs/:id`)
1. "← All jobs" back link.
2. **Row 1:**
   - **Green hero:** status chip (white) and client; title in Inter Tight 52px; address and dates · sq ft; three tiles (Estimate, Invoiced, Complete); buttons "Invoice this job" and "Add change order".
   - **Site photo:** `min-h-[380px]`.
3. **Row 2** (`grid 1.7fr / minmax(300px,1fr)`):
   - **Pricing** (surface): line items as white rows with Description (+ section), Qty, Unit, Rate, Amount, and a "Job total" row at the bottom.
   - **Right column:** Crew (gold tint), Invoices (blue tint) and Materials (surface) mini-lists.

### Materials
- **Stat row:** a solid blue "Spent in October" card, then one tinted card per job.
- **Table:** Material, Job (with a colored dot), Vendor, Date, Qty, Price, Total.

### Invoices
Status filter pills (All, Draft, Sent, Partly paid, Overdue, Paid). Table columns: Invoice no. (mono), Client, Job, Issued, Due (in orange-ink when overdue), Status, Total, Balance.

### New invoice (split view)
A two-column grid, each column 50% wide.
- **Left (form):**
  - Client and Job selects, then Issue date and Due date.
  - "Line items": each item is a surface card holding the description input, Qty, Unit and Rate inputs, and the computed amount.
  - A dashed "Add line item" button.
  - Buttons: "SEND INVOICE" (primary) and "Save draft".
- **Right (preview):** `bg-jx-surface p-10`, containing a sticky white "paper" card (`max-w-[560px] rounded-[20px] p-10 shadow`). The paper shows:
  - company block on the left, and "Invoice" in green Inter Tight 30px with the number on the right;
  - Bill to / Due;
  - the line list (2px ink rule under the header);
  - Subtotal, NYC sales tax 8.875%, and Total due (24px mono, green-ink);
  - a green "PAY ONLINE" bar.

The preview updates live as the form changes.

### Change orders
- **Orange banner:** "N waiting on client sign-off", "Don't start the extra work until it's approved.", and the total pending (40px mono).
- **Card grid** (`minmax(380px,1fr)`). Each card shows the CO number, status chip and signed amount (+/−); the description (Inter Tight 20px); job · invoice; and the reason in a white box.
- **Pending cards** also show "Mark approved" (primary) and "Declined" (secondary) buttons.

### Scheduling
- **Header:** prev/next round buttons and a "This week" pill.
- **Gantt:** a 2-week grid (240px label column plus 10 weekday columns), with today's header filled green. Each job row shows its label card and a tinted bar with a 6px left border in the job color, listing crew names and the date range.
- **"Needs a start date"** (gold tint): quoted jobs with a "Pick dates" button.

### Payroll
- **Stat row:** a solid gold "Total to pay out" card, Gross pay, Taxes withheld, and "Run payroll by" (gold tint).
- **Tabs (pills):**
  - **This pay period:** Employee (avatar, role · W-2/1099), Pay rate, Days, Hours, Gross, Tax, Deductions, Net pay, Status.
  - **Gusto worksheet:** Employee, Regular hrs, Overtime (orange-ink if above 0), Rate, Jobs worked, Gross, plus a "Copy for Gusto" button.
- The "RUN PAYROLL" primary button marks all rows Paid.

### Inbox (merges Inbox Tasks + Gmail Todos)
- **Tabs (pills):** To do, Snoozed, Done, each with a count. These map to `inboxTasks.isDone`, `snoozedUntil` and `dismissed`.
- **Rows** (`rounded-[20px]`, tinted by related module): a 30px round check button that toggles done, a sender initials tile, the sender and time, the subject (Inter Tight 16px), a one-line snippet, an optional related-record chip, and a "Snooze" pill.
- **Empty state:** a green-tint card reading "Nothing here / You're all caught up."

### Settings
Company fields in a 2-column grid, then "Payment reminders" chips (7 days · friendly, 14 days · firm, 30 days · final), which map to `settings.reminderIntervals` and `reminderTones`.

## Interactions
- **Navigation:** every nav button routes to its page, and the active state follows the route (Job detail keeps Jobs active; New invoice keeps Invoices active).
- **Hover:** row cards, nav buttons and pills get a green border on hover. Primary buttons use green-hover.
- **Dark mode:** the toggle in the top bar adds or removes `.dark` on `<html>` and persists the choice in localStorage.
- **Narrow screens:** below roughly 1100px, wide tables scroll sideways inside their rounded container.

## Assets
- Icons: lucide-react (already in the repo).
- Fonts: Inter, Inter Tight and IBM Plex Mono from Google Fonts.
- Photos: placeholders only. The site and job photo slots should use `jobDocuments` images, falling back to a green-tint block.

## Files
- `theme.css`: CSS variables for `index.css`, light and dark.
- `tailwind.config.additions.ts`: Tailwind theme additions.
- `REPLIT_PROMPT.md`: a ready-to-paste instruction for Replit Agent.
- `prototype/JobsOxo App.dc.html` (+ `support.js` and `image-slot.js`): the clickable reference.
- `screenshots/`: the top of each page (01–13), plus the dashboard in dark mode (14). They were captured at a narrow width, so open the prototype to see each page in full.
