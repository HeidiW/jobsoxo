// Merge these into theme.extend in the existing tailwind.config.ts.
// Keep all existing shadcn color entries — these are additions.

export const jobsoxoExtend = {
  fontFamily: {
    sans: ["var(--font-sans)"],
    display: ["var(--font-display)"], // Inter Tight — page titles, card titles
    mono: ["var(--font-mono)"],       // IBM Plex Mono — every money figure, invoice no., qty/rate
  },
  borderRadius: {
    // replaces the current lg/md/sm values
    "3xl": "1.5rem",  // 24px — big cards / panels
    "2xl": "1rem",    // 16px — table rows, inner cards
    xl: "0.875rem",   // 14px — form fields, list items
    lg: "0.75rem",    // 12px
    md: "0.625rem",   // 10px — thumbnails, small chips
    sm: "0.375rem",
  },
  colors: {
    jx: {
      surface: "var(--jx-surface)",
      ink: "var(--jx-ink)",
      "ink-2": "var(--jx-ink-2)",
      "ink-3": "var(--jx-ink-3)",
      line: "var(--jx-line)",
      green: { DEFAULT: "var(--jx-green)", hover: "var(--jx-green-hover)", ink: "var(--jx-green-ink)", tint: "var(--jx-green-tint)" },
      blue: { DEFAULT: "var(--jx-blue)", ink: "var(--jx-blue-ink)", tint: "var(--jx-blue-tint)" },
      orange: { DEFAULT: "var(--jx-orange)", ink: "var(--jx-orange-ink)", tint: "var(--jx-orange-tint)" },
      gold: { DEFAULT: "var(--jx-gold)", ink: "var(--jx-gold-ink)", tint: "var(--jx-gold-tint)" },
    },
  },
  letterSpacing: {
    display: "-0.05em",  // 56–72px page titles
    title: "-0.04em",    // 22–30px card titles
  },
};
