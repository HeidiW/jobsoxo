Paste this into Replit Agent after uploading the `design_handoff_jobsoxo_redesign` folder to the project root.

---

Restyle JobsOxo to match the design in `design_handoff_jobsoxo_redesign/`. Read `README.md` in that folder first; it is the spec. The HTML in `prototype/` is a visual reference only, so don't copy its markup or sample data.

Do this in order and stop after each step so I can check it:

1. **Tokens.** Replace the `:root` and `.dark` variable blocks in `client/src/index.css` with those in `theme.css` (add its font `@import` at the top). Merge `tailwind.config.additions.ts` into `theme.extend` in `tailwind.config.ts`. Don't change any data logic.
2. **App shell.** Update `client/src/components/app-sidebar.tsx` and the top bar to match the README's "Global layout" and "Sidebar navigation" sections:
   - nav items become bordered rounded-full buttons (2px border, filled green when active);
   - move Gusto Worksheet into a tab on the Payroll page;
   - merge Inbox Tasks and Gmail Todos into one Inbox route (keep both old routes redirecting to it);
   - add the dark-mode toggle.
3. **Dashboard.** Rebuild `pages/dashboard.tsx` per the README. Order: This week on site + Needs attention on top, then the green Total outstanding card + site photo, then the three stat cards.
4. **Remaining pages, one at a time:** Jobs, Job detail, Invoices, New invoice (split view with live preview), Clients, Materials, Change Orders, Scheduling, Payroll, Inbox, Settings.

Rules:
- Use the `jx-*` Tailwind colors and `font-display` / `font-mono` classes, not hard-coded hex.
- Every money value uses `font-mono`.
- Keep all existing API calls, forms, validation and routes working. This is a visual redesign only.
- Use existing shadcn components (Button, Badge, Card, Input, Select, Tabs) and restyle them through variants rather than writing new ones.
